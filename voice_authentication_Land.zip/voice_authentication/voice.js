const express = require('express')
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const app = express()
const PORT = 5000

require('./database');

app.use(express.json())

app.listen(PORT, ()=> {
    console.log(`Server is running on port ${PORT}`);
});